; This file contains variable mapping and other information for the current project.

gonextlevel_length = .skipL0287-gonextlevel 
 
sc2 = score + 1
 
sc1 = score
 
zombieypos = player1y 
zombiexpos = player1x 
zombiefinalyvel = u
 
zombiefinalxvel = t
 
zombieyvel = s
 
zombiexvel = r
 
zombievel = temp5 
tempvel8 = temp1 
level = q
 
timer2 = q
 
timer1 = p
 
scadd = o
 
last = n
 
p0y = player0y 
p0x = player0x 
finalyvelocity = m 
finalxvelocity = l 
tempvel = i 
yvelocity = h 
xvelocity = g 
velocity = f 
gamebits = e
 
carframe = c
 
collcount = b
 
turndelay = b
 
carpos = a
 
player1colors = 1
no_blank_lines = 1
