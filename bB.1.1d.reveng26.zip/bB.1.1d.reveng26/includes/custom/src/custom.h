extern volatile unsigned char *queue;
extern volatile unsigned char *flashdata;
